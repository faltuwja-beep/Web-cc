const express = require("express");
const path = require("path");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const app = express();
const PORT = process.env.PORT || 3000;
const SECRET = process.env.JWT_SECRET || "change-me-xenon-secret";
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || "admin@xenon.shop";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "change-me";
const UPI_ID = process.env.UPI_ID || "yourupi@upi";

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const db = {
  users: [],
  deposits: [],
  purchases: [],
  referrals: [],
  products: [
    {id:1,name:"Premium Account",price:99,description:"Premium digital package",icon:"⭐"},
    {id:2,name:"VIP Package",price:199,description:"VIP digital package",icon:"💎"},
    {id:3,name:"Pro Package",price:299,description:"Professional package",icon:"🚀"}
  ]
};

function token(user){ return jwt.sign({id:user.id,email:user.email}, SECRET, {expiresIn:"30d"}); }
function pub(u){ return {id:u.id,name:u.name,email:u.email,balance:u.balance,referralCode:u.referralCode,referralBonus:u.referralBonus}; }
function auth(req,res,next){
  const h=req.headers.authorization||"";
  if(!h.startsWith("Bearer ")) return res.status(401).json({error:"Login required"});
  try { req.user=jwt.verify(h.slice(7),SECRET); next(); }
  catch(e){ res.status(401).json({error:"Session expired"}); }
}
function admin(req,res,next){ if(req.user.email!==ADMIN_EMAIL) return res.status(403).json({error:"Admin only"}); next(); }
function code(){ return "XENON"+Math.random().toString(36).slice(2,8).toUpperCase(); }

app.post("/api/register",async(req,res)=>{
  const name=String(req.body.name||"").trim(), email=String(req.body.email||"").trim().toLowerCase(), password=String(req.body.password||"");
  const referralCode=String(req.body.referralCode||"").trim().toUpperCase();
  if(!name||!email||password.length<6) return res.status(400).json({error:"Name, email and 6+ character password required"});
  if(db.users.some(u=>u.email===email)) return res.status(400).json({error:"Email already registered"});
  const u={id:Date.now().toString(),name,email,passwordHash:await bcrypt.hash(password,10),balance:0,referralCode:code(),referralBonus:0,referredBy:null};
  if(referralCode){const r=db.users.find(x=>x.referralCode===referralCode);if(r)u.referredBy=r.id;}
  db.users.push(u); res.json({token:token(u),user:pub(u)});
});

app.post("/api/login",async(req,res)=>{
  const email=String(req.body.email||"").trim().toLowerCase(), password=String(req.body.password||"");
  const u=db.users.find(x=>x.email===email);
  if(!u || !(await bcrypt.compare(password,u.passwordHash))) return res.status(401).json({error:"Wrong email or password"});
  res.json({token:token(u),user:pub(u)});
});

app.get("/api/me",auth,(req,res)=>{
  const u=db.users.find(x=>x.id===req.user.id);
  if(!u)return res.status(404).json({error:"User not found"});
  res.json(pub(u));
});

app.get("/api/products",(req,res)=>res.json(db.products));
app.get("/api/payment-info",(req,res)=>res.json({upiId:UPI_ID}));

app.post("/api/deposits",auth,(req,res)=>{
  const amount=Number(req.body.amount), utr=String(req.body.utr||"").trim();
  if(amount<=0||!utr)return res.status(400).json({error:"Amount and UTR required"});
  const d={id:Date.now().toString(),userId:req.user.id,amount,utr,status:"PENDING",createdAt:new Date().toISOString()};
  db.deposits.push(d);res.json({message:"Payment submitted",deposit:d});
});

app.get("/api/deposits",auth,(req,res)=>res.json(db.deposits.filter(d=>d.userId===req.user.id).reverse()));

app.post("/api/buy",auth,(req,res)=>{
  const u=db.users.find(x=>x.id===req.user.id), p=db.products.find(x=>x.id===Number(req.body.productId));
  if(!p)return res.status(404).json({error:"Product not found"});
  if(u.balance<p.price)return res.status(400).json({error:"Insufficient balance"});
  u.balance-=p.price;
  db.purchases.push({id:Date.now().toString(),userId:u.id,productId:p.id,amount:p.price,status:"COMPLETED",createdAt:new Date().toISOString()});
  if(u.referredBy && !db.referrals.some(r=>r.referredUserId===u.id)){
    const r=db.users.find(x=>x.id===u.referredBy);
    if(r){r.balance+=50;r.referralBonus+=50;db.referrals.push({referrerId:r.id,referredUserId:u.id,amount:50,status:"PAID",createdAt:new Date().toISOString()});}
  }
  res.json({message:"Purchase successful",user:pub(u)});
});

app.get("/api/referrals",auth,(req,res)=>{
  const u=db.users.find(x=>x.id===req.user.id);
  const rows=db.referrals.filter(r=>r.referrerId===u.id);
  res.json({referralCode:u.referralCode,bonus:u.referralBonus,referrals:rows});
});

app.post("/api/admin/login",(req,res)=>{
  if(req.body.email!==ADMIN_EMAIL||req.body.password!==ADMIN_PASSWORD)return res.status(401).json({error:"Invalid admin login"});
  res.json({token:jwt.sign({id:"admin",email:ADMIN_EMAIL},SECRET,{expiresIn:"30d"})});
});

app.get("/api/admin/deposits",auth,admin,(req,res)=>{
  res.json(db.deposits.map(d=>({...d,user:db.users.find(u=>u.id===d.userId)?.email||"unknown"})).reverse());
});

app.post("/api/admin/deposits/:id",auth,admin,(req,res)=>{
  const d=db.deposits.find(x=>x.id===req.params.id);
  if(!d)return res.status(404).json({error:"Deposit not found"});
  if(d.status!=="PENDING")return res.status(400).json({error:"Already processed"});
  d.status=req.body.status;
  if(d.status==="APPROVED"){const u=db.users.find(x=>x.id===d.userId);if(u)u.balance+=d.amount;}
  res.json(d);
});

app.get("/api/health",(req,res)=>res.json({ok:true}));

app.listen(PORT,()=>console.log(`XENON SHOP running on ${PORT}`));
